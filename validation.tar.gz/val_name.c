#include<stdio.h>
#include<string.h>


int val_name(char name[])
{   
   
    for(int i = 0;i < strlen(name);i++)
    {
        if(!isalpha(name[i]))
        {   
                return 0;
                //break;
        }
        else
        return 1;
        
    }
}



int main()
{
    char name[100];
    printf("Enter name: ");
    scanf("%s", name);
   

    val_name(name);

    return 0;
}


