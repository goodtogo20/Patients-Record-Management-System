#include <stdio.h>


int val_height(char height[])
{

for(int i = 0;i < strlen(height);i++)
{
	if(isdigit(height[i]))
		{
		return 1;		
		}
    else{
	return 0;	
       }
}
}

int main()
{
    char height[100];
    printf("Enter height: ");
    scanf("%s", height);
   

    val_height(height);

    return 0;
}

