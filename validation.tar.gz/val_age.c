#include <stdio.h>


int val_age(char age[])
{

for(int i = 0;i < strlen(age);i++)
{
	if(isdigit(age[i]))
		{
		return 1;		
		}
    else{
	return 0;	
       }
}
}

int main()
{
    char age[100];
    printf("Enter age: ");
    scanf("%s", age);
   

    val_age(age);

    return 0;
}

