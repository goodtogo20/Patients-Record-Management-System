#include <stdio.h>


int val_weight(char weight[])
{

for(int i = 0;i < strlen(weight);i++)
{
	if(isdigit(weight[i]))
		{
		return 1;		
		}
    else{
	return 0;	
       }
}
}

int main()
{
    char weight[100];
    printf("Enter weight: ");
    scanf("%s", weight);
   

    val_weight(weight);

    return 0;
}

