#include <stdio.h>


int val_num(char num[])
{

for(int i = 0;i < strlen(num);i++)
{
	if(isdigit(num[i]) && strlen(num)==10)
		{
		return 1;		
		}
    else{
	    return 0;	
       }
}
}

int main()
{
    char num[100];
    printf("Enter Contact number: ");
    scanf("%s", num);
   

    val_num(num);

    return 0;
}

